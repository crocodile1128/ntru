# NTRU Encryption 
# Author: Tsai Hao-Chang
# Date: 2019/12/23
# ref https://latticehacks.cr.yp.to/ntru.html
import numpy as np
def mod(a, n):
    return ((a + n//2) % n) - n//2

def egcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(mod(b, a), a)
        return (g, x - (b // a) * y, y)

def modinv(a, m):
    if a < 0:
        a = a + m
    g, x, y = egcd(a, m)
    if g != 1:
        raise Exception('modular inverse does not exist')
    else:
        return mod(x,m)

# Addition
def poly_add(x, y):
    if x.size == y.size:
        res = x + y
    else:
        if x.size > y.size:
            y = np.append(np.zeros(x.size - y.size, dtype=int), y)
            res = x + y
        else:
            x = np.append(np.zeros(y.size - x.size, dtype=int), x)
            res = x + y
    while res.size != 0 and res[0] == 0:
        res = np.delete(res, 0)
    return res

def poly_minus(x, y):
    if x.size == y.size:
        res = x - y
    else:
        if x.size > y.size:
            y = np.append(np.zeros(x.size - y.size, dtype=int), y)
            res = x - y
        else:
            x = np.append(np.zeros(y.size - x.size, dtype=int), x)
            res = x - y
    while res.size != 0 and res[0] == 0:
        res = np.delete(res, 0)
    return res

def poly_scalar(a, x):
    return a * x

def poly_mul(x, y):
    length = x.size + y.size - 1
    res = np.zeros(length, dtype=int)
    for i in range(len(x)):
        # shift
        tmp = np.append(np.zeros(x.size-i-1, dtype=int), y)
        tmp = np.append(tmp, np.zeros(i, dtype=int))
        # scalar multiple
        tmp = poly_scalar(x[x.size-i-1], tmp)
        # addition
        res = (res + tmp)
    return res

# Modular reduction
def balanced_mod(f, p):
    res = list(((f[i] + p//2) % p) - p//2 for i in range(f.size))
    return np.array(res)

# Random polynomial r for encryption
# returns an n-coefficient polynomial where exactly d coefficients 
# are nonzero with 1 or -1 (d are nonzero, the other n-d are all zero).
from random import randrange
def random_d_poly(d, n):
    assert d <= n
    res = n*[0]
    for j in range(d):
        while True:
            r = randrange(n)
            if not res[r]: break
        res[r] = 1 - 2*randrange(2)
    return np.array(res)

def convolution(f, g, n):
    fg = poly_mul(f, g)
    fg = np.append(np.zeros(n - fg.size % n, dtype=int), fg)
    res = np.zeros(n, dtype=int)
    for i in range(fg.size):
        res[i%n] += fg[i]
    return res
# https://ieeexplore.ieee.org/stamp/stamp.jsp?arnumber=4800404
def poly_div(x, y, p):
    while x.size > 0 and x[0] == 0:
        x = np.delete(x, 0)
    while y.size > 0 and y[0] == 0:
        y = np.delete(y, 0)
    if x.size >= y.size:
        ql = x.size - y.size + 1
        q = np.zeros(ql, dtype=int)
        u = modinv(y[0], p)
        for i in range(ql):
            if x.size >= y.size and x[0] != 0:
                q[i] = x[0] * u
            else:
                q[i] = 0
            v = (q[i] * np.append(y, np.zeros(ql-i-1, dtype=int)))
            #print (v)
            x = x - v
            x = np.delete(x, 0)
        while x.size > 0 and x[0] == 0:
            x = np.delete(x, 0)
        r = balanced_mod(x, p)
    else:
        q = np.array([0])
        r = x
    q = q
    r = r
    return q, r

def ext_eculid(x, y, p, n):
    r = np.array([0])
    f, g = x, y
    #t1 = np.append(np.zeros(n-1, dtype=int), np.array([0]))
    #t2 = np.append(np.zeros(n-1, dtype=int), np.array([1]))
    t1 = np.array([0])
    t2 = np.array([1])
    while r.size != 1 or r[0] != 1:   
        q, r = poly_div(f, g, p)
        t = poly_minus(t1, poly_mul(t2, q))
        t = t % p
        print (q, f, g, r, t1, t2, t)
        f, g = g, r
        t1, t2 = t2, t
        
    inv = t2
    return inv

N = 7
p = 3
f = np.array([1,0,0,0,0,0,0,1])
g = np.array([-1,1,1,-1,1])
inverse = ext_eculid(f, g, p, N)
print (poly_div(f,g,p))
print (inverse) # [1,0,2,0,0,1,0]
print (convolution(inverse, g, 7)) # [3,-3,3,0,0,0,1]
